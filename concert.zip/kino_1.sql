-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Сен 15 2022 г., 17:34
-- Версия сервера: 5.6.47-log
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kino`
--

-- --------------------------------------------------------

--
-- Структура таблицы `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `login`
--

INSERT INTO `login` (`id`, `login`, `password`, `name`) VALUES
(1, 'user', 'user', 'Дмитрий Палыч');

-- --------------------------------------------------------

--
-- Структура таблицы `zakaz1`
--

CREATE TABLE `zakaz1` (
  `id` int(11) NOT NULL,
  `inf` varchar(255) NOT NULL,
  `inf1` varchar(255) NOT NULL,
  `inf2` varchar(255) NOT NULL,
  `inf3` varchar(255) NOT NULL,
  `ryad1` varchar(255) NOT NULL,
  `bilet1` varchar(255) NOT NULL,
  `cena1` varchar(255) NOT NULL,
  `ryad2` varchar(255) NOT NULL,
  `bilet2` varchar(255) NOT NULL,
  `cena2` varchar(255) NOT NULL,
  `ryad3` varchar(255) NOT NULL,
  `bilet3` varchar(255) NOT NULL,
  `cena3` varchar(255) NOT NULL,
  `ryad4` varchar(255) NOT NULL,
  `bilet4` varchar(255) NOT NULL,
  `cena4` varchar(255) NOT NULL,
  `ryad5` varchar(255) NOT NULL,
  `bilet5` varchar(255) NOT NULL,
  `cena5` varchar(255) NOT NULL,
  `ryad6` varchar(255) NOT NULL,
  `bilet6` varchar(255) NOT NULL,
  `cena6` varchar(255) NOT NULL,
  `ryad7` varchar(255) NOT NULL,
  `bilet7` varchar(255) NOT NULL,
  `cena7` varchar(255) NOT NULL,
  `ryad8` varchar(255) NOT NULL,
  `bilet8` varchar(255) NOT NULL,
  `cena8` varchar(255) NOT NULL,
  `ryad9` varchar(255) NOT NULL,
  `bilet9` varchar(255) NOT NULL,
  `cena9` varchar(255) NOT NULL,
  `ryad10` varchar(255) NOT NULL,
  `bilet10` varchar(255) NOT NULL,
  `cena10` varchar(255) NOT NULL,
  `mesto1` varchar(255) NOT NULL,
  `mesto2` varchar(255) NOT NULL,
  `mesto3` varchar(255) NOT NULL,
  `mesto4` varchar(255) NOT NULL,
  `mesto5` varchar(255) NOT NULL,
  `mesto6` varchar(255) NOT NULL,
  `mesto7` varchar(255) NOT NULL,
  `mesto8` varchar(255) NOT NULL,
  `mes1` varchar(255) NOT NULL,
  `mes2` varchar(255) NOT NULL,
  `mes3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `zakaz1`
--

INSERT INTO `zakaz1` (`id`, `inf`, `inf1`, `inf2`, `inf3`, `ryad1`, `bilet1`, `cena1`, `ryad2`, `bilet2`, `cena2`, `ryad3`, `bilet3`, `cena3`, `ryad4`, `bilet4`, `cena4`, `ryad5`, `bilet5`, `cena5`, `ryad6`, `bilet6`, `cena6`, `ryad7`, `bilet7`, `cena7`, `ryad8`, `bilet8`, `cena8`, `ryad9`, `bilet9`, `cena9`, `ryad10`, `bilet10`, `cena10`, `mesto1`, `mesto2`, `mesto3`, `mesto4`, `mesto5`, `mesto6`, `mesto7`, `mesto8`, `mes1`, `mes2`, `mes3`) VALUES
(1, 'Место:', 'Ряд:', 'Цена:', 'Заказ:', '1', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '2', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '3', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '4', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '5', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '6', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '7', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '8', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '9', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '10', '500 Руб', '<a href=\"#zatemnenie\">Заказать</a>', ' <input type=\"checkbox\"> 1', '<input type=\"checkbox\"> 2', '<input type=\"checkbox\"> 3', '<input type=\"checkbox\"> 4', '<input type=\"checkbox\"> 5', '<input type=\"checkbox\"> 6', '<input type=\"checkbox\"> 7', '<input type=\"checkbox\"> 8', '1', '2', '3');

-- --------------------------------------------------------

--
-- Структура таблицы `zakaz2`
--

CREATE TABLE `zakaz2` (
  `id` int(11) NOT NULL,
  `inf1` varchar(255) NOT NULL,
  `inf2` varchar(255) NOT NULL,
  `inf3` varchar(255) NOT NULL,
  `ryad1` varchar(255) NOT NULL,
  `bilet1` varchar(255) NOT NULL,
  `cena1` varchar(255) NOT NULL,
  `ryad2` varchar(255) NOT NULL,
  `bilet2` varchar(255) NOT NULL,
  `cena2` varchar(255) NOT NULL,
  `ryad3` varchar(255) NOT NULL,
  `bilet3` varchar(255) NOT NULL,
  `cena3` varchar(255) NOT NULL,
  `ryad4` varchar(255) NOT NULL,
  `bilet4` varchar(255) NOT NULL,
  `cena4` varchar(255) NOT NULL,
  `ryad5` varchar(255) NOT NULL,
  `bilet5` varchar(255) NOT NULL,
  `cena5` varchar(255) NOT NULL,
  `ryad6` varchar(255) NOT NULL,
  `bilet6` varchar(255) NOT NULL,
  `cena6` varchar(255) NOT NULL,
  `ryad7` varchar(255) NOT NULL,
  `bilet7` varchar(255) NOT NULL,
  `cena7` varchar(255) NOT NULL,
  `ryad8` varchar(255) NOT NULL,
  `bilet8` varchar(255) NOT NULL,
  `cena8` varchar(255) NOT NULL,
  `ryad9` varchar(255) NOT NULL,
  `bilet9` varchar(255) NOT NULL,
  `cena9` varchar(255) NOT NULL,
  `ryad10` varchar(255) NOT NULL,
  `bilet10` varchar(255) NOT NULL,
  `cena10` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `zakaz2`
--

INSERT INTO `zakaz2` (`id`, `inf1`, `inf2`, `inf3`, `ryad1`, `bilet1`, `cena1`, `ryad2`, `bilet2`, `cena2`, `ryad3`, `bilet3`, `cena3`, `ryad4`, `bilet4`, `cena4`, `ryad5`, `bilet5`, `cena5`, `ryad6`, `bilet6`, `cena6`, `ryad7`, `bilet7`, `cena7`, `ryad8`, `bilet8`, `cena8`, `ryad9`, `bilet9`, `cena9`, `ryad10`, `bilet10`, `cena10`) VALUES
(1, 'Ряд:', 'Цена:', 'Заказ:', '1', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '2', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '3', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '4', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '5', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '6', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '7', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '8', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '9', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '10', '600 Руб', '<a href=\"#zatemnenie\">Заказать</a>');

-- --------------------------------------------------------

--
-- Структура таблицы `zakaz3`
--

CREATE TABLE `zakaz3` (
  `id` int(11) NOT NULL,
  `inf1` varchar(255) NOT NULL,
  `inf2` varchar(255) NOT NULL,
  `inf3` varchar(255) NOT NULL,
  `ryad1` varchar(255) NOT NULL,
  `bilet1` varchar(255) NOT NULL,
  `cena1` varchar(255) NOT NULL,
  `ryad2` varchar(255) NOT NULL,
  `bilet2` varchar(255) NOT NULL,
  `cena2` varchar(255) NOT NULL,
  `ryad3` varchar(255) NOT NULL,
  `bilet3` varchar(255) NOT NULL,
  `cena3` varchar(255) NOT NULL,
  `ryad4` varchar(255) NOT NULL,
  `bilet4` varchar(255) NOT NULL,
  `cena4` varchar(255) NOT NULL,
  `ryad5` varchar(255) NOT NULL,
  `bilet5` varchar(255) NOT NULL,
  `cena5` varchar(255) NOT NULL,
  `ryad6` varchar(255) NOT NULL,
  `bilet6` varchar(255) NOT NULL,
  `cena6` varchar(255) NOT NULL,
  `ryad7` varchar(255) NOT NULL,
  `bilet7` varchar(255) NOT NULL,
  `cena7` varchar(255) NOT NULL,
  `ryad8` varchar(255) NOT NULL,
  `bilet8` varchar(255) NOT NULL,
  `cena8` varchar(255) NOT NULL,
  `ryad9` varchar(255) NOT NULL,
  `bilet9` varchar(255) NOT NULL,
  `cena9` varchar(255) NOT NULL,
  `ryad10` varchar(255) NOT NULL,
  `bilet10` varchar(255) NOT NULL,
  `cena10` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `zakaz3`
--

INSERT INTO `zakaz3` (`id`, `inf1`, `inf2`, `inf3`, `ryad1`, `bilet1`, `cena1`, `ryad2`, `bilet2`, `cena2`, `ryad3`, `bilet3`, `cena3`, `ryad4`, `bilet4`, `cena4`, `ryad5`, `bilet5`, `cena5`, `ryad6`, `bilet6`, `cena6`, `ryad7`, `bilet7`, `cena7`, `ryad8`, `bilet8`, `cena8`, `ryad9`, `bilet9`, `cena9`, `ryad10`, `bilet10`, `cena10`) VALUES
(1, 'Ряд:', 'Цена:', 'Заказ:', '1', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '2', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '3', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '4', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '5', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '6', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '7', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '8', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '9', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>', '10', '700 Руб', '<a href=\"#zatemnenie\">Заказать</a>');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `zakaz1`
--
ALTER TABLE `zakaz1`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `zakaz2`
--
ALTER TABLE `zakaz2`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `zakaz3`
--
ALTER TABLE `zakaz3`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `zakaz1`
--
ALTER TABLE `zakaz1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `zakaz2`
--
ALTER TABLE `zakaz2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `zakaz3`
--
ALTER TABLE `zakaz3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
