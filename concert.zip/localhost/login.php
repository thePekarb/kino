<?php

$conn = mysqli_connect("localhost", "root", "root", "kino");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}




?>
<!DOCTYPE HTML>
<html>
 <head>
  <meta charset="utf-8">
  <title>Авторизация</title>
  <link rel="stylesheet" href="css/style.css">
 </head>
 <body>
 <form action="check.php" class='form' method="POST">
<p>Логин</p>
<input class="input" name="login" type="text" required>
<p>Пароль</p>  
<input class="input" name="password" type="password" required>
<input class="but" name="submit" type="submit" value="Войти">
<p class="text_reg"><a href="register.php" id='reg_text'>Регистрация</a></p>
<p class="text_reg"><a href="index.html" id='reg_text'>Назад</a></p>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
    
    <meta name="generator" content="Jonas John" />
    <meta name="description" content="put a good description in here" />
    <meta name="keywords" content="good,keywords" />
    
    <link rel="stylesheet" type="text/css" href="css/bluesky.css" media="screen, tv, projection" title="Default" />
    <link rel="alternative stylesheet" type="text/css" href="css/bluesky_large.css" media="screen, projection, tv" title="Larger Fonts" />
    
    <link rel="alternative stylesheet" type="text/css" href="css/print.css" media="screen" title="Print Preview" />
    <link rel="alternative stylesheet" type="text/css" href="css/handheld.css" media="screen" title="Small Layout Preview" />
    
    <link rel="stylesheet" type="text/css" href="css/handheld.css" media="handheld" title="Small Layout" />
    <link rel="stylesheet" type="text/css" href="css/print.css" media="print" />

    <link rel="top" href="index.html" title="Homepage" />
    <link rel="up" href="index.html" title="Up" />
    <link rel="first" href="index.html" title="First page" />
    <link rel="previous" href="index.html" title="Previous page" />
    <link rel="next" href="index.html" title="Next page" />
    <link rel="last" href="index.html" title="Last page" />
    <link rel="toc" href="index.html" title="Table of contents" />
    <link rel="index" href="index.html" title="Site map" />
</form>   
 </body>
