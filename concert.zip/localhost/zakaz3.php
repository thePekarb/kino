<?php
session_start();
$login = $_SESSION['name'];
$conn = mysqli_connect("localhost", "root", "root", "kino");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT * FROM `zakaz3`";
$result = mysqli_query($conn, $sql);
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$newww = "SELECT * FROM `zakaz3`";
$newResult = mysqli_query($conn, $newww);

?>
<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/opensans-web-font.css" />
        <link rel="stylesheet" href="assets/css/montserrat-web-font.css" />

		
        <link rel="stylesheet" href="assets/css/font-awesome.min.css" />

        
        <link rel="stylesheet" href="assets/css/style.css">

        
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        
		
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <nav class="mainmenu navbar navbar-default navbar-fixed-top">
            <div class="container">
			
			<div class="row">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					
					<div class="brand-bg">
                    <a href="index.php">Кинчик</a>
					</div>
                </div>


                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav pull-right">
                        
                    <a href="index.html">Выйти</a>
                        <?php

        $sql = "SELECT name FROM login WHERE login='$login'";
        $result = mysqli_query($conn, $sql);
        $row= mysqli_fetch_array($result, MYSQLI_ASSOC);

    ?>
    <?php
       echo "<p class='name'>" .$row['name']. "</p>";
?>
                    </ul>
                </div>
				</div>
				
            </div>
        </nav>
	
			<header class="home-bg2">
				<div class="overlay-img2">
					<div class="container">
						<div class="row">
							<div class="col-md-6 col-sm-12 col-xs-12">
								<div class="header-details">
									<h1>Прокат в этом зале:<br> Фильм 7, Фильм 8, Фильм 9<i class="fa fa-circle"></i></h1>
                                    <button class="btn btn-default">Заказать</button>
								</div>
							</div>
							
		
						</div>
					</div>
				</div>	
				</header>
                 
        <section id="promotion-area" class="sections">
            <div class="container">
                
                <div class="row">
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="promotion">	
                        <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<h4>" . $newRow['inf1'] . "</h4>";
                    echo "<h4>" . $newRow['ryad1'] . "</h4>";
                    echo "<h4>" . $newRow['ryad2'] . "</h4>";
                    echo "<h4>" . $newRow['ryad3'] . "</h4>";
                    echo "<h4>" . $newRow['ryad4'] . "</h4>";
                    echo "<h4>" . $newRow['ryad5'] . "</h4>";
                    echo "<h4>" . $newRow['ryad6'] . "</h4>";
                    echo "<h4>" . $newRow['ryad7'] . "</h4>";
                    echo "<h4>" . $newRow['ryad8'] . "</h4>";
                    echo "<h4>" . $newRow['ryad9'] . "</h4>";
                    echo "<h4>" . $newRow['ryad10'] . "</h4>";
                    ?>
                    <?php
                }
                ?>					
						</div>
					</div>
					
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="promotion">
                        <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<h4>" . $newRow['inf2'] . "</h4>";
                    echo "<h4>" . $newRow['bilet1'] . "</h4>";
                    echo "<h4>" . $newRow['bilet2'] . "</h4>";
                    echo "<h4>" . $newRow['bilet3'] . "</h4>";
                    echo "<h4>" . $newRow['bilet4'] . "</h4>";
                    echo "<h4>" . $newRow['bilet5'] . "</h4>";
                    echo "<h4>" . $newRow['bilet6'] . "</h4>";
                    echo "<h4>" . $newRow['bilet7'] . "</h4>";
                    echo "<h4>" . $newRow['bilet8'] . "</h4>";
                    echo "<h4>" . $newRow['bilet9'] . "</h4>";
                    echo "<h4>" . $newRow['bilet10'] . "</h4>";
                    ?>
                    <?php
                }
                ?>
						</div>
					</div>
					
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="promotion">
                        <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<h4>" . $newRow['inf3'] . "</h4>";
                    echo "<h4>" . $newRow['cena1'] . "</h4>";
                    echo "<h4>" . $newRow['cena2'] . "</h4>";
                    echo "<h4>" . $newRow['cena3'] . "</h4>";
                    echo "<h4>" . $newRow['cena4'] . "</h4>";
                    echo "<h4>" . $newRow['cena5'] . "</h4>";
                    echo "<h4>" . $newRow['cena6'] . "</h4>";
                    echo "<h4>" . $newRow['cena7'] . "</h4>";
                    echo "<h4>" . $newRow['cena8'] . "</h4>";
                    echo "<h4>" . $newRow['cena9'] . "</h4>";
                    echo "<h4>" . $newRow['cena10'] . "</h4>";
                    ?>
                    <?php
                }
                ?>
						</div>
					</div>

                </div>
            </div>       
        </section>
		
		<div class="scroll-top">
		
			<div class="scrollup">
				<i class="fa fa-angle-double-up"></i>
			</div>
			
		</div>
	
        <footer>
            <div class="container">
			<hr>
            	<div class="row">
				
            		<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="social-network">
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-instagram"></i></a>
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-google-plus"></i></a>
						</div>
					</div>
					
            		<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="copyright">
							<p>Кинчик <i class="fa fa-heart"></i>Дешёвое кино </a>2022</p>
						</div>
					</div>
					
            	</div>
            </div>
        </footer>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>