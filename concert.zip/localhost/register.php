<html>
<head>
<meta charset="utf-8">
  <link rel="stylesheet" href="css/style.css">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <title>Регистрация</title>
</head>
<body>

<form  class='form' action="register.php" method="POST" />

            <p>Имя и Фамилию</p>
            <input class="input" type="text" name="name" />

            <p>Логин</p>
            <input class="input" type="text"  name="login" />

            <p>Пароль</p>
           <input class="input" type="password"  maxlength="20" name="password" />

            <input class="but" type="submit" value="Зарегистрироваться" name="submit" />
</form>

<?php
$connection = mysqli_connect('localhost', 'root', 'root', 'kino') or die(mysqli_error($connection));

if (isset($_POST['submit'])) 
{
    if (empty($_POST['login'])) 
    {
        $info_reg = 'Вы не ввели Логин';
    }          
    elseif (empty($_POST['name'])) 
    {
        $info_reg = 'Вы не ввели имя';
    }           
    elseif (empty($_POST['password'])) 
    {
        $info_reg = 'Вы не ввели пароль';
    }                      
    else 
    {
        $login = $_POST['login'];
        $name = $_POST['name'];               
        $password = $_POST['password'];
  
        $query = "INSERT INTO `login` (login, password, name)
        VALUES ('$login', '$password', '$name')";
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
                    
        $info_reg = 'Вы успешно зарегистрировались!';
        
    }
}

$info_reg = isset($info_reg) ? $info_reg : NULL;
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
    
    <meta name="generator" content="Jonas John" />
    <meta name="description" content="put a good description in here" />
    <meta name="keywords" content="good,keywords" />
    
    <link rel="stylesheet" type="text/css" href="css/bluesky.css" media="screen, tv, projection" title="Default" />
    <link rel="alternative stylesheet" type="text/css" href="css/bluesky_large.css" media="screen, projection, tv" title="Larger Fonts" />
    
    <link rel="alternative stylesheet" type="text/css" href="css/print.css" media="screen" title="Print Preview" />
    <link rel="alternative stylesheet" type="text/css" href="css/handheld.css" media="screen" title="Small Layout Preview" />
    
    <link rel="stylesheet" type="text/css" href="css/handheld.css" media="handheld" title="Small Layout" />
    <link rel="stylesheet" type="text/css" href="css/print.css" media="print" />

    <link rel="top" href="index.html" title="Homepage" />
    <link rel="up" href="index.html" title="Up" />
    <link rel="first" href="index.html" title="First page" />
    <link rel="previous" href="index.html" title="Previous page" />
    <link rel="next" href="index.html" title="Next page" />
    <link rel="last" href="index.html" title="Last page" />
    <link rel="toc" href="index.html" title="Table of contents" />
    <link rel="index" href="index.html" title="Site map" />

</body>
</html>