<?php
$conn = mysqli_connect("localhost", "root", "root", "concert");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT * FROM `infoconcert`";
$result = mysqli_query($conn, $sql);
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$newww = "SELECT * FROM `infoconcert`";
$newResult = mysqli_query($conn, $newww);

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="style2.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
            <p><h1 class="logotext">БАСТА ТУР</h1></p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
          
            <ul class="menu">
                <li><a href="zal1.php">Купить билеты</a></li>
                <li><a href="">Контакты</a></li>
                <li><a href="">Об авторе</a></li>
                <li><a href="log.php">вход</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/db3196f5-f4b4-4c4d-a787-a529a0226842.jpg"></a></div>
                <div class="post-content">
                    <div class="category">Концерты Басты 2022-2023</div>
                    <h2 class="post-title"></h2>
                    
                    <div class="post-footer">
                            <div class="post-cont">
                            <?php
                            foreach ($newResult as $newRow) {
                            ?>
                            <?php
                                echo "<h2 class='korzina__wrapper'>" . $newRow['mount'] . "</h2>";
                                echo "<h2 class='korzina__abr'>" . $newRow['date'] . "</h2>";
                                echo "<h2 class='korzina__abr'>" . $newRow['place'] . "</h2>";
                                echo "<h2 class='korzina__abr'>" . $newRow['price'] . "</h2>";
                                echo "<h2 class='korzina__about'>" . $newRow['buy'] . "</h2>";
                            
                                ?>
                                <?php
                            }
                            ?>
                            </div>
                    </div>
                </div>
            </article>
            
        </div> <!-- конец div class="posts-list"-->
    </div>
    <footer>
        <div class="container">
           
            <div class="footer-cols">
                <a href="mailto:admin@yoursite.ru">концерты.ру</a>
            </div>
        </div>
    </footer>

</body>

</html>


<form  class='form' action="reg.php" method="POST" >

            <p>Имя и Фамилию</p>
            <input class="input" type="text" name="name" />

            <p>Логин</p>
            <input class="input" type="text"  name="login" />

            <p>Пароль</p>
           <input class="input" type="password"  maxlength="20" name="password" />

            <input class="but" type="submit" value="Зарегистрироваться" name="submit" />
               <p class="text_reg"><a href="log.php" id='reg_text'>Назад</a></p>
</form>

<?php
$connection = mysqli_connect('localhost', 'root', 'root', 'concert') or die(mysqli_error($connection));

if (isset($_POST['submit'])) 
{
    if (empty($_POST['login'])) 
    {
        $info_reg = 'Вы не ввели Логин';
    }          
    elseif (empty($_POST['name'])) 
    {
        $info_reg = 'Вы не ввели имя';
    }           
    elseif (empty($_POST['password'])) 
    {
        $info_reg = 'Вы не ввели пароль';
    }                      
    else 
    {
        $login = $_POST['login'];
        $name = $_POST['name'];               
        $password = $_POST['password'];
  
        $query = "INSERT INTO `login` (login, password, name)
        VALUES ('$login', '$password', '$name')";
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
                    
        $info_reg = 'Вы успешно зарегистрировались!';
        
    }
}

$info_reg = isset($info_reg) ? $info_reg : NULL;
?>