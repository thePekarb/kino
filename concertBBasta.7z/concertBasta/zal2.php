<?php
session_start();
$login = $_SESSION['name'];
$conn = mysqli_connect("localhost", "root", "root", "concert");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT * FROM `zakaz`";
$result = mysqli_query($conn, $sql);
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$newww = "SELECT * FROM `zakaz`";
$newResult = mysqli_query($conn, $newww);

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p>Купить билеты.ру</p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
            <form action="" method="get" id="searchform">
                <input type="text" placeholder="Искать на сайте...">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            <ul class="menu">
                <li><a class="ag" href="index2.php">Купить билеты</a></li>
                <li><a class="ag" href="">Контакты</a></li>
                <li><a class="ag"  href="korzina.php">Корзина</a></li>
                <li><a class="ag" href="log.php">Выход</a></li>
                <li><a>
                    <?php

        $sql = "SELECT name FROM login WHERE login='$login'";
        $result = mysqli_query($conn, $sql);
        $row= mysqli_fetch_array($result, MYSQLI_ASSOC);

    ?>
    <?php
       echo "<p class='name'>" .$row['name']. "</p>";
?>
                    </a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/IMG_0409-17-05-18-04-55.jpg"></a></div>
                <div class="post-content">
           
                    <h2 class="post-title">Концерт Баста</h2>
                    <p>Ждём всех на конецерте Василия Вакуленко в Москве, спешите купить билеты.</p>
                    <div class="calendar-item">
			<div class="calendar-head">Октябрь 2022</div>
			<table>
				<tr>
					<th>Пн</th>
					<th>Вт</th>
					<th>Ср</th>
					<th>Чт</th>
					<th>Пт</th>
					<th>Сб</th>
					<th>Вс</th>
				</tr><tr><td></td><td></td><td></td><td></td><td></td><td class="calendar-day last">1</td><td class="calendar-day last">2</td></tr><tr><td class="calendar-day last">3</td><td class="calendar-day today">4</td><td class="calendar-day ">5</td><td class="calendar-day ">6</td><td class="calendar-day ">7</td><td class="calendar-day ">8</td><td class="calendar-day ">9</td></tr><tr><td class="calendar-day ">10</td><td class="calendar-day ">11</td><td class="calendar-day ">12</td><td class="calendar-day ">13</td><td class="calendar-day ">14</td><td class="calendar-day ">15</td><td class="calendar-day ">16</td></tr><tr><td class="calendar-day ">17</td><td class="calendar-day ">18</td><td class="calendar-day ">19</td><td class="calendar-day ">20</td><td class="calendar-day ">21</td><td class="calendar-day ">22</td><td class="calendar-day ">23</td></tr><tr><td class="calendar-day ">24</td><td class="calendar-day ">25</td><td class="calendar-day ">26</td><td class="calendar-day ">27</td><td class="calendar-day ">28</td><td class="calendar-day ">29</td><td class="calendar-day ">30</td></tr><tr><td class="calendar-days "><a href="#432451"></a>31</td></tr></table></div>
				<a class="more-links"><h1>Концерт в 19:00</h1></a>


                    <div class="post-footer">
                       <div class="row">
					
                       <div class="post-cont">
                    <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<div class='korzina__wrapper'>";
                    echo "<h2>" . $newRow['ryad'] . "</h2>";
                    echo "<h2 class='korzina__abr'>" . $newRow['cost'] . "</h2>";
                    
                    echo "<h2 class='korzina__about'>" . $newRow['zakaz'] . "</h2>";
                    echo "</div>"
                    ?>
                    <?php
                  }
                ?>
                    </div>
					
					
				
                </div>
                      
                    </div>
                </div>
            </article>
          
        </div> <!-- конец div class="posts-list"-->
    </div>
<footer class='footer'>
        
        <div class="container footer__container">
            <div class="footer__wrapper">
                <p class="footer__paragraph">
                    bileti.ru
                </p>
                <div class="footer__pics">
                    <img src="" alt="">
                    <img src="" alt="">
                    <img src="" alt="">
                </div>
            </div>
        </div>
</footer>
</body>
 

</html>