<html>
<head>
<meta charset="utf-8">
  <link rel="stylesheet" href="css/style.css">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <title>Регистрация</title>
</head>
<body>

<form  class='form' action="reg.php" method="POST" >

            <p>Имя и Фамилию</p>
            <input class="input" type="text" name="name" />

            <p>Логин</p>
            <input class="input" type="text"  name="login" />

            <p>Пароль</p>
           <input class="input" type="password"  maxlength="20" name="password" />

            <input class="but" type="submit" value="Зарегистрироваться" name="submit" />
               <p class="text_reg"><a href="log.php" id='reg_text'>Назад</a></p>
</form>

<?php
$connection = mysqli_connect('localhost', 'root', 'root', 'concert') or die(mysqli_error($connection));

if (isset($_POST['submit'])) 
{
    if (empty($_POST['login'])) 
    {
        $info_reg = 'Вы не ввели Логин';
    }          
    elseif (empty($_POST['name'])) 
    {
        $info_reg = 'Вы не ввели имя';
    }           
    elseif (empty($_POST['password'])) 
    {
        $info_reg = 'Вы не ввели пароль';
    }                      
    else 
    {
        $login = $_POST['login'];
        $name = $_POST['name'];               
        $password = $_POST['password'];
  
        $query = "INSERT INTO `login` (login, password, name)
        VALUES ('$login', '$password', '$name')";
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
                    
        $info_reg = 'Вы успешно зарегистрировались!';
        
    }
}

$info_reg = isset($info_reg) ? $info_reg : NULL;
?>

</body>
</html>