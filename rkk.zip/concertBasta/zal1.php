<?php
session_start();
$login = $_SESSION['name'];
$conn = mysqli_connect("localhost", "root", "root", "concert");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT * FROM `zakaz1`";
$result = mysqli_query($conn, $sql);
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$newww = "SELECT * FROM `zakaz1`";
$newResult = mysqli_query($conn, $newww);

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p>Купить билеты.ру</p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
            <form action="" method="get" id="searchform">
                <input type="text" placeholder="Искать на сайте...">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            <ul class="menu">
                <li><a class="a1" href="buyticket.php">Купить билеты</a></li>
                <li><a class="a1" href="">Контакты</a></li>
                <li><a class="a1"  href="">Об авторе</a></li>
                <li><a class="a1" href="log.php">Выход</a></li>
                <li><a>
                    <?php

        $sql = "SELECT name FROM login WHERE login='$login'";
        $result = mysqli_query($conn, $sql);
        $row= mysqli_fetch_array($result, MYSQLI_ASSOC);

    ?>
    <?php
       echo "<p class='name'>" .$row['name']. "</p>";
?>
                    </a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/IMG_0409-17-05-18-04-55.jpg"></a></div>
                <div class="post-content">
           
                    <h2 class="post-title">Концерт Баста</h2>
                    <p>Ждём всех на конецерте Василия Вакуленко в Москве, спешите купить билеты.</p>
                    <div class="post-footer">
                       <div class="row">
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="promotion">	
                        <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<h4>" . $newRow['inf1'] . "</h4>";
                    echo "<h4>" . $newRow['ryad1'] . "</h4>";
                    echo "<h4>" . $newRow['ryad2'] . "</h4>";
                    echo "<h4>" . $newRow['ryad3'] . "</h4>";
                    echo "<h4>" . $newRow['ryad4'] . "</h4>";
                    echo "<h4>" . $newRow['ryad5'] . "</h4>";
                    echo "<h4>" . $newRow['ryad6'] . "</h4>";
                    echo "<h4>" . $newRow['ryad7'] . "</h4>";
                    echo "<h4>" . $newRow['ryad8'] . "</h4>";
                    echo "<h4>" . $newRow['ryad9'] . "</h4>";
                    echo "<h4>" . $newRow['ryad10'] . "</h4>";
                    ?>
                    <?php
                }
                ?>
						</div>
					</div>
					
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="promotion">
                        <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<h4>" . $newRow['inf2'] . "</h4>";
                    echo "<h4>" . $newRow['bilet1'] . "</h4>";
                    echo "<h4>" . $newRow['bilet2'] . "</h4>";
                    echo "<h4>" . $newRow['bilet3'] . "</h4>";
                    echo "<h4>" . $newRow['bilet4'] . "</h4>";
                    echo "<h4>" . $newRow['bilet5'] . "</h4>";
                    echo "<h4>" . $newRow['bilet6'] . "</h4>";
                    echo "<h4>" . $newRow['bilet7'] . "</h4>";
                    echo "<h4>" . $newRow['bilet8'] . "</h4>";
                    echo "<h4>" . $newRow['bilet9'] . "</h4>";
                    echo "<h4>" . $newRow['bilet10'] . "</h4>";
                    ?>
                    <?php
                }
                ?>
						</div>
					</div>
					
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="promotion">
                        <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<h4>" . $newRow['inf3'] . "</h4>";
                    echo "<h4>" . $newRow['cena1'] . "</h4>";
                    echo "<h4>" . $newRow['cena2'] . "</h4>";
                    echo "<h4>" . $newRow['cena3'] . "</h4>";
                    echo "<h4>" . $newRow['cena4'] . "</h4>";
                    echo "<h4>" . $newRow['cena5'] . "</h4>";
                    echo "<h4>" . $newRow['cena6'] . "</h4>";
                    echo "<h4>" . $newRow['cena7'] . "</h4>";
                    echo "<h4>" . $newRow['cena8'] . "</h4>";
                    echo "<h4>" . $newRow['cena9'] . "</h4>";
                    echo "<h4>" . $newRow['cena10'] . "</h4>";
                    ?>
                    <?php
                }
                ?>
						</div>
					</div>

                </div>
                      
                    </div>
                </div>
            </article>
          
        </div> <!-- конец div class="posts-list"-->
    </div>
<footer class='footer'>
        
        <div class="container footer__container">
            <div class="footer__wrapper">
                <p class="footer__paragraph">
                    bileti.ru
                </p>
                <div class="footer__pics">
                    <img src="" alt="">
                    <img src="" alt="">
                    <img src="" alt="">
                </div>
            </div>
        </div>
</footer>
</body>
 

</html>