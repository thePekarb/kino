<?php

$conn = mysqli_connect("localhost", "root", "root", "concert");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}

?>
<!DOCTYPE HTML>
<html>
 <head>
  <meta charset="utf-8">
  <title>Авторизация</title>
  <link rel="stylesheet" href="css/reg.css">
 </head>
 <body>
 <header>
        <nav class="container nav__container">
            <a class="banner"><img src="image/basta_main_desk_new2.jpg" alt=""></a>
            <a class="logo" href="">
                <p>БАСТА ТУР.RU</p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
            
          
                    
                    </a></li>
            </ul>
        </nav>
    </header>
            <form action="check.php" class='form' method="POST">
            <p>Логин</p>
            <input class="input" name="login" type="text" required>
            <p>Пароль</p>  
            <input class="input" name="password" type="password" required>
            <input class="but" name="submit" type="submit" value="Войти">
            <p class="text_reg"><a href="reg.php" id='reg_text'>Регистрация</a></p>
            <p class="text_reg"><a href="index.php" id='reg_text'>Назад</a></p>

            </form>   
 </body>