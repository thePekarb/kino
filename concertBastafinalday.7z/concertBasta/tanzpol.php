<?php
session_start();
$conn = mysqli_connect("localhost", "root", "root", "concert");
$login = $_SESSION['name'];
$userInfoSelect = "SELECT * FROM `stranica` WHERE login = '$login'";
$userInfoSelectResult = mysqli_query($conn, $userInfoSelect);
$userInfoFetchAssoc = mysqli_fetch_assoc($userInfoSelectResult);
if (isset($_POST['redact']) && !empty($userInfoFetchAssoc)) {
} else if (empty($userInfoFetchAssoc) && isset($_POST['redact'])) {
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p>Купить билеты.ру</p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
            <form action="" method="get" id="searchform">
                <input type="text" placeholder="Искать на сайте...">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            <ul class="menu">
                <li><a class="a1" href="buyticket.php">Купить билеты</a></li>
                <li><a class="a1" href="">Контакты</a></li>
                <li><a class="a1"  href="korzina.php">Корзина</a></li>
                <li><a class="a1" href="log.php">Выход</a></li>
                <li><a>
                    <?php

        $sql = "SELECT name FROM login WHERE login='$login'";
        $result = mysqli_query($conn, $sql);
        $row= mysqli_fetch_array($result, MYSQLI_ASSOC);

    ?>
    <?php
       echo "<p class='name'>" .$row['name']. "</p>";
?>
                    </a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/IMG_0409-17-05-18-04-55.jpg"></a></div>
                <div class="post-content">
           
                    <h2 class="post-title">Укажите количество мест</h2>
                    <p>цена билета 2000руб</p>
                    <p></p>

                    <?php 
                    
                    $ticketSelect = "SELECT * FROM `ticket_info` WHERE id = 2";
                    $ticketSelectResult = mysqli_query($conn, $ticketSelect);
                    ?>
                     <h1>количество билетов: <?php foreach($ticketSelectResult as $ticketRow) {
                        echo "$ticketRow[ticket_count]";
                     } ?>
                     </h1>
                    
                     <div class="userList">

                <div class="userInfo">
                    

                        <form  method='POST' class='redform'>
                        <label for=''>ФИО:</label>
                        <textarea name='full_name' cols='20' rows='4' class='input'></textarea>
                        <label for=''>кол-во билетов:</label>
                        <input type='text' class='input' name='ticket' required>
                        <label for=''>название ряда:</label>
                        <textarea name='about' cols='20' rows='4' class='input'></textarea>
                        <input type='submit' name='redsubmit' class='btn' value='Редактировать'>
                        </form>
                   
                    
                    <?php
                if (isset($_POST['redsubmit'])) {

                    $full_name = $_POST["full_name"];
                    $ticket = $_POST["ticket"];
                    $about = $_POST["about"];
                  
                    $userPageInsert = "INSERT INTO stranica (login, full_name, ticket, about, avatar) VALUES ('$login', '$full_name', '$ticket', '$about', '')";
                    $ticketUpdate = "UPDATE `ticket_info` SET ticket_count = ticket_count-$ticket WHERE id = 2";
                    if ($conn->query($userPageInsert)) {
                      
                    } else {
                        echo "Ошибка: " . $conn->error;
                    }
                    if ($conn->query($ticketUpdate)) {
                        echo "<p>Данные обновлены</p>";
                        ?>
                            
                         <script> 
                         
                            window.location.replace('http://concertbasta/korzina.php');
                            
                         </script>
                            
                        <?php
                    }
                }

                ?>
                </div>
                
            </div>
                    
                </div>
            </article>
          
        </div> <!-- конец div class="posts-list"-->
    </div>
<footer class='footer'>
        
        <div class="container footer__container">
            <div class="footer__wrapper">
                <p class="footer__paragraph">
                    bileti.ru
                </p>
                <div class="footer__pics">
                   
                </div>
            </div>
        </div>
</footer>
</body>
 

</html>