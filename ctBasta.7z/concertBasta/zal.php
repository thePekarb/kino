<?php
session_start();
$login = $_SESSION['name'];
$conn = mysqli_connect("localhost", "root", "root", "concertb");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT * FROM `zal`";
$result = mysqli_query($conn, $sql);
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$newww = "SELECT * FROM `zal`";
$newResult = mysqli_query($conn, $newww);

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="style2.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p>Купить билеты.ру</p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
            <form action="" method="get" id="searchform">
                <input type="text" placeholder="Искать на сайте...">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            <ul class="menu">
                <li><a class="ag" href="index2.php">Купить билеты</a></li>
                <li><a class="ag" href="">Контакты</a></li>
                <li><a class="ag"  href="korzina.php">Корзина</a></li>
                <li><a class="ag" href="log.php">Выход</a></li>
                <li><a>
                    <?php

        $sql = "SELECT name FROM login WHERE login='$login'";
        $result = mysqli_query($conn, $sql);
        $row= mysqli_fetch_array($result, MYSQLI_ASSOC);

    ?>
    <?php
       echo "<p class='name'>" .$row['name']. "</p>";
?>
                    </a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/IMG_0409-17-05-18-04-55.jpg"></a></div>
                <div class="post-content">
           
                   <center> <h1 class="post-title">Выберите зал</h1></center>
                    <p></p>
                    
				

                    <div class="post-footer">
                       <div class="row">
					
                       <div class="post-cont">
                    <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<div class='korzina__wrappers'>";
                    echo "<h2>" . $newRow['name'] . "</h2>";
                    echo "<h2 class='korzina__abouts'>" . $newRow['countplace'] . "</h2>";
                    echo "</div>"
                    ?>
                    <?php
                  }
                ?>
                    </div>
					
					
				
                </div>
                      
                    </div>
                </div>
            </article>
          
        </div> <!-- конец div class="posts-list"-->
    </div>
<footer class='footer'>
        
        <div class="container footer__container">
            <div class="footer__wrapper">
                <p class="footer__paragraph">
                    bileti.ru
                </p>
                <div class="footer__pics">
                    <img src="" alt="">
                    <img src="" alt="">
                    <img src="" alt="">
                </div>
            </div>
        </div>
</footer>
</body>
 

</html>