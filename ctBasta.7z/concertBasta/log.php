<?php

$conn = mysqli_connect("localhost", "root", "root", "concert");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p><h1 class="logotext">БАСТА ТУР</h1></p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
          
            
        </nav>
        
    </header>
    <div class="headerdown">
<p><H3 class="logoup">официальный сайт концертов басты</H3></p>
            </div>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/basta_main_desk_new2.jpg"></a></div>
                <div class="post-content">
                    
                    <h2 class="post-title">Авторизация/регистрация</h2>
                    <p>
                    <center><form action="check.php" class='form' method="POST">
            <p>Логин</p>
            <input class="input" name="login" type="text" required>
            <p>Пароль</p>  
            <input class="input" name="password" type="password" required>
            <P></P>
            <input class="but" name="submit" type="submit" value="Войти">
            <p class="text_reg"><a href="reg.php" id='reg_text'>Регистрация</a></p>
            <p class="text_reg"><a href="index.php" id='reg_text'>Назад</a></p>

            </form>  </center>  
                    </p>
                    
                </div>
            </article>
            
        </div> <!-- конец div class="posts-list"-->
    </div>
    <footer>
        <div class="container">
           <div class="footer-cols"> <center><span>www.bastaTUR.ru</span>
        
            
                <a href="mailto:admin@yoursite.ru">концерты.ру</a></center>
            </div>
            
        </div>
    </footer>

</body>

</html>