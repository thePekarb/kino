<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p><h1 class="logotext">GAZGOLDER & BOOKING MACHINE</h1></p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
          
            
        </nav>
        
    </header>
    <div class="headerdown">
<p><H3 class="logoup">официальный сайт концертов басты GAZGOLDER & BOOKING MACHINE</H3></p>
            </div>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/basta_main_desk_new2.jpg"></a></div>
                <div class="post-content">
                    
                    <h2 class="post-title">Регистрация</h2>
                    <p>
                        <center><form  class='form' action="reg.php" method="POST" >

                            <p>Имя и Фамилию</p>
                            <input class="input" type="text" name="name" />

                            <p>Логин</p>
                            <input class="input" type="text"  name="login" />

                            <p>Пароль</p>
                            <input class="input" type="password"  maxlength="20" name="password" />
                            <p></p>

                            <input class="but" type="submit" value="Зарегистрироваться" name="submit" />
                            <p class="text_reg"><a href="index.php" id='reg_text'>Назад</a></p>
                            </form>
                         </center>  
                    </p>
                                                <?php
                            $connection = mysqli_connect('localhost', 'root', 'root', 'concertb') or die(mysqli_error($connection));

                            if (isset($_POST['submit'])) 
                            {
                                if (empty($_POST['login'])) 
                                {
                                    $info_reg = 'Вы не ввели Логин';
                                }          
                                elseif (empty($_POST['name'])) 
                                {
                                    $info_reg = 'Вы не ввели имя';
                                }           
                                elseif (empty($_POST['password'])) 
                                {
                                    $info_reg = 'Вы не ввели пароль';
                                }                      
                                else 
                                {
                                    $login = $_POST['login'];
                                    $name = $_POST['name'];               
                                    $password = $_POST['password'];
                            
                                    $query = "INSERT INTO `login` (login, password, name)
                                    VALUES ('$login', '$password', '$name')";
                                    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
                                                
                                    $info_reg = 'Вы успешно зарегистрировались!';
                                    
                                }
                            }

                            $info_reg = isset($info_reg) ? $info_reg : NULL;
                            ?>
                </div>
            </article>
            
        </div> <!-- конец div class="posts-list"-->
    </div>
    <footer>
        <div class="container">
           <div class="footer-cols"> <center><span>www.bastaTUR.ru</span>
        
            
                <a href="mailto:admin@yoursite.ru">концерты.ру</a></center>
            </div>
            
        </div>
    </footer>

</body>

</html>
