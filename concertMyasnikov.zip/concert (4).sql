-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 07 2022 г., 18:42
-- Версия сервера: 8.0.19
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `concert`
--

-- --------------------------------------------------------

--
-- Структура таблицы `login`
--

CREATE TABLE `login` (
  `id` int NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `login`
--

INSERT INTO `login` (`id`, `login`, `password`, `name`) VALUES
(2, 'gg', '123', 'Sergey Myasnikov'),
(3, 'tt', '123', 'Вячеслав ff');

-- --------------------------------------------------------

--
-- Структура таблицы `stranica`
--

CREATE TABLE `stranica` (
  `id` int NOT NULL,
  `login` varchar(111) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ticket` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `about` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `stranica`
--

INSERT INTO `stranica` (`id`, `login`, `full_name`, `ticket`, `about`, `avatar`) VALUES
(29, 'gg', 'grg', '5', 'parter', '');

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_info`
--

CREATE TABLE `ticket_info` (
  `id` int NOT NULL,
  `ticket_count` int NOT NULL,
  `concert_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `ticket_info`
--

INSERT INTO `ticket_info` (`id`, `ticket_count`, `concert_id`) VALUES
(1, 20, ''),
(2, 63, ''),
(3, 30, ''),
(4, 15, ''),
(5, 10, '');

-- --------------------------------------------------------

--
-- Структура таблицы `zakaz2`
--

CREATE TABLE `zakaz2` (
  `id` int NOT NULL,
  `ryad` varchar(255) NOT NULL,
  `cost` varchar(255) NOT NULL,
  `zakaz` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `zakaz2`
--

INSERT INTO `zakaz2` (`id`, `ryad`, `cost`, `zakaz`) VALUES
(1, 'Ряд', 'Цена', 'Заказ'),
(2, 'Партер', '1000 руб', '<p><a href=\"parter.php\">Заказать</a></p>'),
(3, 'Танцпол', '1500 руб', '<p><a href=\"tanzpol.php\">Заказать</a></p>'),
(4, 'Фанзона', '2000 руб', '<p><a href=\"fanzone.php\">Заказать</a></p>'),
(5, 'VipZone', '3500 руб', '<p><a href=\"vip.php\">Заказать</a></p>'),
(6, 'SuperVip', '5000 руб', '<p><a href=\"supervip.php\">Заказать</a></p>');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `stranica`
--
ALTER TABLE `stranica`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `ticket_info`
--
ALTER TABLE `ticket_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `zakaz2`
--
ALTER TABLE `zakaz2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `login`
--
ALTER TABLE `login`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `stranica`
--
ALTER TABLE `stranica`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT для таблицы `ticket_info`
--
ALTER TABLE `ticket_info`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `zakaz2`
--
ALTER TABLE `zakaz2`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
