<?php
session_start();
$login = $_SESSION['name'];
$conn=mysqli_connect("localhost", "root", "root", "concert");

if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
  }

  $newww = "SELECT * FROM `stranica`";
$newResult = mysqli_query($conn, $newww);
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адаптивная вёрстка сайта</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700,700italic|Playfair+Display:400,700&subset=latin,cyrillic">
    <link rel="stylesheet" type="text/css" href="style2.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
</head>

<body>
    <header>
        <nav class="container nav__container">
            <a class="logo" href="">
                <p>Купить билеты.ру</p>
            </a>
            <!-- <div class="nav-toggle"><span></span></div> -->
            <form action="" method="get" id="searchform">
                <input type="text" placeholder="Искать на сайте...">
                <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            <ul class="menu">
                <li><a href="index2.php">Купить билеты</a></li>
                <li><a href="">Контакты</a></li>
                <li><a href="">Об авторе</a></li>
                <li><a href="log.php">Выход</a></li>
                <li><a>
                    <?php

        $sql = "SELECT name FROM login WHERE login='$login'";
        $result = mysqli_query($conn, $sql);
        $row= mysqli_fetch_array($result, MYSQLI_ASSOC);

    ?>
    <?php
       echo "<p class='name'>" .$row['name']. "</p>";
?>
                    </a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="posts-list">
            <article id="post-1" class="post">
                <div class="post-image"><a href=""><img src="image/IMG_0409-17-05-18-04-55.jpg"></a></div>
                    <div class="post-content">
           
                    <h2 class="post-title">Купленные билеты</h2>
                    <p>подробная информация</p>
                    <div class="post-menu">
                        <h2>Логин</h2>
                        <h2>ФИО</h2>
                        <h2>Кол-во билетов</h2>
                        <h2>Название ряда</h2>
                    </div>
                    <div class="post-cont">
                    <?php
                foreach ($newResult as $newRow) {
                    ?>
                    <?php
                    echo "<div class='korzina__wrapper'>";
                    echo "<h2>" . $newRow['login'] . "</h2>";
                    echo "<h2>" . $newRow['full_name'] . "</h2>";
                    echo "<h2>" . $newRow['ticket'] . "</h2>";
                    echo "<h2 class='korzina__about'>" . $newRow['about'] . "</h2>";
                    echo "</div>"
                    ?>
                    <?php
                  }
                ?>
                    </div>

      

    
                    
                    <div class="post-footer">
                        
                        <div class="post-social">
                            <a href="" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="" target="_blank"><i class="fa fa-pinterest"></i></a>
                        </div>
                    </div>
                </div>
            </article>
          
        </div> <!-- конец div class="posts-list"-->
    </div>
<footer class='footer'>
        
        <div class="container footer__container">
            <div class="footer__wrapper">
                <p class="footer__paragraph">
                    bileti.ru
                </p>
                <div class="footer__pics">
                    <img src="" alt="">
                    <img src="" alt="">
                    <img src="" alt="">
                </div>
            </div>
        </div>
</footer>
</body>
 

</html>