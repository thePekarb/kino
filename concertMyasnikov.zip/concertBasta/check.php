<?php
session_start();
if (isset($_POST['login']) && isset($_POST['password'])) {
    $log = $_POST['login'];
    $pas = $_POST['password'];
}
$conn = mysqli_connect("localhost", "root", "root", "concert");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT login FROM login WHERE login = '$log' and password='$pas'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
if ($row !=null) {
$_SESSION['name']= $log;
header("Location: index2.php");
}
?>