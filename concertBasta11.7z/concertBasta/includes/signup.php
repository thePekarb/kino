<?php
session_start();
if(!empty($_POST['submitauth'])){
    header('Refresh: 0');

}
if (isset($_SESSION['userid'])) {
    header('Location: ../index2.php');
}
$conn = mysqli_connect("localhost", "root", "root", "concert");

if (isset($_POST['submitreg'])) {
    $login = $_POST['login'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $name = $_POST['name'];
    $userInsertion = "INSERT INTO `users` (`login`, `password`, `name`) VALUES ('$login', '$password', '$name')";

    if ($conn->query($userInsertion)) {
        echo "<p>" . "Регистрация прошла успешно" . "</p>";
        header('Location: ../index.php');
    } else {
        echo "<p>" . "Ошибка:" . $conn->error . "</p>";
    }
}
?>